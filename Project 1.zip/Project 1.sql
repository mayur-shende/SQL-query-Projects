-------------------------------------- Project: Querying a Large Relational Database --------------------------------------

-- RESTORE DATABASE ADVENTUREWORKS2012
USE AdventureWorks2012

/*    

Problem Statement:
How to get details about customers by querying a database?

Topics:
In this project, you will work on downloading a database and restoring it on the
server. You will then query the database to get customer details like name, phone
number, email ID, sales made in a particular month, increase in month-on-month
sales and even the total sales made to a particular customer.

Highlights:
Table basics and data types
Various SQL operators
Various SQL functions

*/

-- a. Get all the details from the person table including email ID, phone number and phone number type

SELECT * 
FROM PERSON.EMAILADDRESS
LEFT JOIN PERSON.PERSONPHONE ON
PERSON.EMAILADDRESS.BUSINESSENTITYID = PERSON.PERSONPHONE.BUSINESSENTITYID
LEFT JOIN Person.PhoneNumberType ON
Person.PersonPhone.PhoneNumberTypeID = Person.PhoneNumberType.PhoneNumberTypeID

-- OR --

SELECT *
FROM Person.EmailAddress, Person.PhoneNumberType, Person.PersonPhone
WHERE Person.EmailAddress.BusinessEntityID = Person.PersonPhone.BusinessEntityID AND Person.PhoneNumberType.PhoneNumberTypeID = Person.PersonPhone.PhoneNumberTypeID

-- b. Get the details of the sales header order made in May 2011

SELECT *
FROM SALES.SALESORDERHEADER
WHERE  ORDERDATE BETWEEN '2011-05-01' AND '2011-05-31'

-- OR

SELECT * FROM SALES.SALESORDERHEADER
WHERE MONTH(ORDERDATE) = 5 AND YEAR(ORDERDATE) = 2011

-- c. Get the details of the sales details order made in the month of May 2011

SELECT *
FROM SALES.SALESORDERDETAIL
INNER JOIN SALES.SALESORDERHEADER ON
SALES.SALESORDERDETAIL.SALESORDERID = SALES.SALESORDERHEADER.SALESORDERID
WHERE MONTH(ORDERDATE) = '05' AND YEAR(ORDERDATE) = '2011'

-- d. Get the total sales made in May 2011

SELECT SUM(TOTALDUE) AS [TOTAL SALES]
FROM SALES.SALESORDERHEADER
WHERE MONTH(ORDERDATE) = '05' AND YEAR(ORDERDATE) = '2011'

-- e. Get the total sales made in the year 2011 by month order by increasing sales

SELECT SUM(TOTALDUE) AS [TOTAL SALES], MONTH(ORDERDATE) AS MONTH
FROM SALES.SALESORDERHEADER
WHERE YEAR(ORDERDATE) = '2011'
GROUP BY MONTH(ORDERDATE)
ORDER BY [TOTAL SALES] ASC

-- f. Get the total sales made to the customer with FirstName='Gustavo' and LastName ='Achong'

SELECT FirstName, LastName, SUM(TOTALDUE) AS [TOTAL SALES]
FROM Sales.Customer S 
INNER JOIN Person.Person P ON P.BusinessEntityID = S.CustomerID
INNER JOIN Sales.SalesOrderHeader SOH ON SOH.TerritoryID = S.TerritoryID
WHERE FirstName = 'GUSTAVO' AND LastName = 'ACHONG'
GROUP BY FirstName, LastName