--- CREATE DATABASE ---

CREATE DATABASE CASESTUDY
USE CASESTUDY

/*

Problem Statement:
You are the database developer of an international bank. You are responsible for
managing the bank�s database. You want to use the data to answer a few
questions about your customers regarding withdrawal, deposit and so on,
especially about the transaction amount on a particular date across various
regions of the world. Perform SQL queries to get the key insights of a customer.

*/

-- 1. Display the count of customers in each region who have done the transaction in the year 2020.
SELECT REGION_NAME, COUNT(CUSTOMER_ID) AS TOTAL_CUSTOMERS
FROM CUSTOMERS
INNER JOIN CONTINENT ON
CUSTOMERS.REGION_ID = CONTINENT.REGION_ID
GROUP BY REGION_NAME

-- 2. Display the maximum and minimum transaction amount of each transaction type.
SELECT UPPER(TXN_TYPE) AS TRANSACTION_TYPE, MAX(TXN_AMOUNT)AS MAX_TXN_AMOUNT, MIN(TXN_AMOUNT) AS MIN_TXN_AMOUNT
FROM [TRANSACTION]
GROUP BY TXN_TYPE

-- 3. Display the customer id, region name and transaction amount where transaction type is deposit and transaction amount > 2000.
SELECT T.CUSTOMER_ID, C.REGION_NAME, T.TXN_AMOUNT, T.TXN_TYPE
FROM [TRANSACTION] T, CONTINENT C
WHERE T.TXN_TYPE = 'DEPOSIT' AND TXN_AMOUNT > 2000

-- 4. Find duplicate records in the Customer table.
SELECT CUSTOMER_ID, COUNT(CUSTOMER_ID) AS NO_OF_DUPLICATES
FROM CUSTOMERS
GROUP BY CUSTOMER_ID
HAVING COUNT(CUSTOMER_ID) > 1

-- 5. Display the customer id, region name, transaction type and transaction amount for the minimum transaction amount in deposit.
SELECT CS.CUSTOMER_ID, C.REGION_NAME, T.TXN_TYPE, T.TXN_AMOUNT
FROM CUSTOMERS CS, CONTINENT C, [TRANSACTION] T
WHERE T.TXN_TYPE = 'DEPOSIT' AND T.TXN_AMOUNT = (SELECT MIN(TXN_AMOUNT) FROM [TRANSACTION])

-- 6. Create a stored procedure to display details of customers in the Transaction table where the transaction date is greater than Jun 2020.
CREATE PROCEDURE SP_CUSTOMER_DETAILS 
AS
BEGIN
	SELECT * 
	FROM [TRANSACTION] T
	INNER JOIN CUSTOMERS C ON C.CUSTOMER_ID = T.CUSTOMER_ID
	WHERE TXN_DATE > '2020-01-01'
	ORDER BY  C.CUSTOMER_ID
END
EXEC SP_CUSTOMER_DETAILS

-- 7. Create a stored procedure to insert a record in the Continent table.
CREATE PROCEDURE INSERT_INTO_CONTINENT
AS
BEGIN
	INSERT INTO CONTINENT 
	VALUES(6, 'CANADA')
END
EXEC INSERT_INTO_CONTINENT

SELECT * FROM CONTINENT

-- 8. Create a stored procedure to display the details of transactions that happened on a specific day.
CREATE PROCEDURE TXN_SPECIAL_DAY @DAY VARCHAR(20) AS
SELECT C.CUSTOMER_ID,
	TXN_TYPE,
	TXN_DATE,
	TXN_AMOUNT,
	DATENAME(DW, TXN_DATE) DATE_NAME

FROM CUSTOMERS C
INNER JOIN [TRANSACTION] T ON T.CUSTOMER_ID = C.CUSTOMER_ID
WHERE DATENAME(DW, TXN_DATE) = @DAY 
GO
EXEC TXN_SPECIAL_DAY @DAY = 'TUESDAY'

-- 9. Create a user defined function to add 10% of the transaction amount in a table.
CREATE FUNCTION INCREASE_TXN_AMOUNT(@AMOUNT FLOAT)
RETURNS FLOAT
AS
BEGIN
RETURN @AMOUNT * 1.1
END 
SELECT TXN_AMOUNT, [DBO].[INCREASE_TXN_AMOUNT](TXN_AMOUNT) AS [10% OF AMOUNT]
FROM [TRANSACTION]

-- 10. Create a user defined function to find the total transaction amount for a given transaction type.
CREATE FUNCTION FN_TRANSACTION_DETAILS(@TRANS_TYPE VARCHAR(20))
RETURNS TABLE
AS
RETURN    
	SELECT TXN_TYPE, SUM(TXN_AMOUNT) AS TOTAL_AMOUNT
	FROM[TRANSACTION]
	WHERE TXN_TYPE = @TRANS_TYPE
	GROUP BY TXN_TYPE

SELECT * 
FROM [DBO].[FN_TRANSACTION_DETAILS] ('DEPOSIT')

-- 11. Create a table value function which comprises the columns customer_id, region_id ,txn_date , txn_type , txn_amount which will retrieve data from the above table.
CREATE FUNCTION FN_DISPLAY_ALL_DETAILS()
RETURNS TABLE AS
RETURN
SELECT 	DISTINCT C.CUSTOMER_ID, REGION_ID, TXN_AMOUNT, TXN_DATE, TXN_TYPE   
	FROM   CUSTOMERS C 
	INNER JOIN   [TRANSACTION] T ON C.CUSTOMER_ID = T.CUSTOMER_ID   

SELECT * 
FROM [DBO].[FN_DISPLAY_ALL_DETAILS]()
ORDER BY CUSTOMER_ID

-- 12. Create a TRY...CATCH block to print a region id and region name in a single column.
BEGIN TRY
SELECT CONCAT_WS(' = ', REGION_ID, REGION_NAME) REGION_ID_AND_NAME
FROM CONTINENT
END TRY
BEGIN CATCH   
	SELECT ERROR_MESSAGE() 
END CATCH

-- 13. Create a TRY...CATCH block to insert a value in the Continent table.
BEGIN TRY   
SELECT (' = ' + REGION_ID + REGION_NAME) REGION_ID_AND_NAME
FROM CONTINENT
END TRY
BEGIN CATCH
	SELECT ERROR_MESSAGE()
END CATCH

-- TO SHOW ERROR MESSAGE

BEGIN TRY
INSERT INTO CONTINENT
VALUES(7, 'ANTARCTICA')
END TRY
BEGIN CATCH
	SELECT ERROR_MESSAGE()
END CATCH

SELECT DISTINCT(region_id), region_name FROM CONTINENT

-- 14. Create a trigger to prevent deleting a table in a database.
CREATE DATABASE SAMPLE_DBO
USE SAMPLE_DBO

CREATE TABLE SAMPLE_TABLE(
	ID INT PRIMARY KEY,
	SALARY INT
)

INSERT INTO SAMPLE_TABLE
VALUES
	(1, 10000),
	(2, 20000)

CREATE TRIGGER PREVENT_DEL_TABLE ON DATABASE FOR DROP_TABLE
AS
BEGIN
ROLLBACK
PRINT('ACCESS DENIED!!!  TABLES CAN NOT BE DELETED FROM THE DATABASE....')
END

DROP TABLE SAMPLETABLE

SELECT * 
FROM SAMPLE_TABLE


-- 15. Create a trigger to audit the data in a table.
CREATE DATABASE SampleDB
USE SampleDB
CREATE TRIGGER tr_AuditTableChangesON ALL SERVER
FOR CREATE_TABLE, ALTER_TABLE, DROP_TABLE

AS
BEGIN
	DECLARE @EventData XML
	SELECT @EventData = EVENTDATA()

INSERT INTO SampleDB.dbo.TableChanges
(DatabaseName, TableName, EventType, LoginName, SQLCommand, AuditDateTime)    VALUES
(
@EventData.value('(/EVENT_INSTANCE/DatabaseName) [1]', 'VARCHAR(250)'),
@EventData.value('(/EVENT_INSTANCE/ObjectName) [1]', 'VARCHAR(250)'),
@EventData.value('(/EVENT_INSTANCE/EventType) [1]', 'VARCHAR(250)'),
@EventData.value('(/EVENT_INSTANCE/LoginName) [1]', 'VARCHAR(250)'),
@EventData.value('(/EVENT_INSTANCE/TSQLCommand) [1]', 'VARCHAR(2500)'),
GETDATE()
)   
END

CREATE TABLE TableChanges
(
DatabaseName NVARCHAR(250),
TableName NVARCHAR(250),
EventType NVARCHAR(250),
LoginName NVARCHAR(250),
SQLCommand NVARCHAR(2500),
AuditDateTime DATETIME
)
SELECT * FROM TableChanges
CREATE TABLE AuditTest
(
ID INT
)
DROP TABLE AuditTest

-- 16. Create a trigger to prevent login of the same user id in multiple pages.
CREATE TRIGGER tr_AuditLogin
ON ALL SERVER
FOR LOGON
AS
BEGIN
	DECLARE @LoginName nvarchar(100)
		SET @LoginName = Original_Login()
	IF(SELECT COUNT(*) FROM sys.dm_exec_sessions
	WHERE is_user_process = 1 AND original_login_name = @LoginName) > 3
	BEGIN
	PRINT 'Fourth Connection Attempt by ' + @LoginName + ' Blocked'   
	ROLLBACK
	END
END

-- 17. Display top n customers on the basis of transaction type.
CREATE FUNCTION FN_TOP_CUSTOMERS(@t_TYPE VARCHAR(25), @n_TOP INT) -- TXN TYPE AND NO OF TOP n
RETURNS TABLE AS
RETURN
	SELECT DISTINCT TOP (@n_TOP) C.CUSTOMER_ID, TXN_TYPE, TXN_AMOUNT,TXN_DATE   
	FROM CUSTOMERS C
	INNER JOIN [TRANSACTION] T ON C.CUSTOMER_ID = T.CUSTOMER_ID
	WHERE TXN_TYPE = @t_TYPE
	ORDER BY TXN_AMOUNT DESC

SELECT * FROM [DBO].[FN_TOP_CUSTOMERS] ('PURCHASE', 1000)

-- 18. Create a pivot table to display the total purchase, withdrawal and deposit for all the customers.
SELECT *
FROM 	(
		SELECT CUSTOMER_ID, TXN_TYPE, TXN_DATE, TXN_AMOUNT
		FROM [TRANSACTION]
	)  TXN_TABLE
PIVOT	(
	SUM(TXN_AMOUNT)
	FOR TXN_TYPE IN ([PURCHASE], [WITHDRAWAL], [DEPOSIT])
	) PIVOT_TABLE
ORDER BY CUSTOMER_ID

