
----
CREATE TABLE LOCATION_07
( LOCATION_ID INT PRIMARY KEY,
CITY VARCHAR(50))

INSERT INTO LOCATION_07(LOCATION_ID,CITY) VALUES(122,'NEWYORK'),(123 ,'DALLAS'),(124 ,'CHICAGO'),(167,'BOSTON')

SELECT * FROM LOCATION_07


CREATE TABLE DEPARTMENT_07
(DEPARTMENT_ID INT PRIMARY KEY,
NAME VARCHAR(50),
LOCATION_ID INT,
FOREIGN KEY(LOCATION_ID) REFERENCES LOCATION_07(LOCATION_ID)
);

INSERT INTO DEPARTMENT_07(DEPARTMENT_ID,NAME,LOCATION_ID) 
VALUES (10,'ACCOUNTING', 122),(20,'SALES',124),(30,'RESEARCH',123),(40, 'OPERATIONS',167)

SELECT * FROM  DEPARTMENT_07

CREATE TABLE JOB_12(JOB_ID INT PRIMARY KEY,DESIGNATION VARCHAR(50))

INSERT INTO JOB_12(JOB_ID,DESIGNATION) VALUES (667,'CLERK'),(668,'STAFF'),(669,'ANALYST'),(670,'SALESPERSON'),(671,'MANAGER'),(672,'PRESIDENT')



CREATE TABLE EMPLOYEE_15 (
    Employee_Id INT PRIMARY KEY,
    Last_Name VARCHAR(50),
    First_Name VARCHAR(50),
    Middle_Name VARCHAR(50),
    Job_Id INT,
    Manager_Id INT,
    Hire_Date DATE,
    Salary NUMERIC(10,2),
    Commission NUMERIC(10,2),
    Department_Id INT,
    FOREIGN KEY (Job_Id) REFERENCES JOB_12(Job_Id),
    FOREIGN KEY (Department_Id) REFERENCES DEPARTMENT_07(Department_Id)
);

INSERT INTO EMPLOYEE_15(Employee_Id, Last_Name, First_Name, Middle_Name, Job_Id, Manager_Id, Hire_Date, Salary, Commission, Department_Id)
VALUES (7369, 'SMITH', 'JOHN', 'Q', 667, 7902, '1984-12-17', 800, NULL, 20),
       (7499, 'KEVIN', 'ALLEN', 'J', 670, 7698, '1985-02-20', 1600, 300, 30),
       (7505, 'DOYLE', 'JEAN', 'K', 671, 7839, '1985-04-04', 2850, NULL, 30),
       (7506, 'DENIS', 'LYNN', 'S', 671, 7839, '1985-05-15', 2750, NULL, 30),
       (7507, 'BRAKER', 'LESLIE', 'D', 671, 7839, '1985-06-10', 2200, NULL, 40),
       (7521, 'WARK', 'CYNTHIA', 'D', 670, 7698, '1985-02-22', 1250, 500, 30);



--1.	List all the employee details.

SELECT * FROM EMPLOYEE_15
--2.	List all the department details.
SELECT * FROM DEPARTMENT_07
--3.	List all job details
SELECT * FROM JOB_12
--4.	List all the locations.
SELECT * FROM LOCATION_07
--5.	List out the First Name, Last Name, Salary, Commission for all Employees.
SELECT First_Name,Last_Name,Salary,Commission FROM EMPLOYEE_15
--6.	List out the Employee ID, Last Name, Department ID for all employees and alias
--Employee ID as "ID of the Employee", Last Name as "Name of the Employee", Department ID as "Dep_id"
SELECT Employee_Id AS 'ID_OF_THE_EMPLOYEE',Last_Name AS 'NAME OF THE EMPLOYEE',Department_Id AS 'DEP_ID' FROM EMPLOYEE_15
--7.	List out the annual salary of the employees with their names only.
SELECT CONCAT(FIRST_NAME,' ',Last_Name) AS EMPLOYEE_NAME,Salary*12 AS ANUUAL_SALARY FROM EMPLOYEE_15

--1.	List the details about "Smith".
SELECT Last_Name,Employee_Id,Salary,Commission,Manager_Id,First_Name,Middle_Name,Hire_Date FROM EMPLOYEE_15 WHERE Last_Name='SMITH'
--2.	List out the employees who are working in department 20.
SELECT Employee_Id,First_Name,Last_Name,Salary,Department_Id,Salary FROM EMPLOYEE_15 WHERE Department_Id=20
--3.	List out the employees who are earning salaries between 3000 and 4500.
SELECT Employee_Id,First_Name,Last_Name,Salary FROM EMPLOYEE_15 WHERE Salary BETWEEN 3000 AND 4500
--4.	List out the employees who are working in department 10 or 20.
SELECT Employee_Id,First_Name,Last_Name,Salary,Department_Id FROM EMPLOYEE_15 WHERE Department_Id IN(10,20)
--5.	Find out the employees who are not working in department 10 or 30.
SELECT Employee_Id,First_Name,Last_Name,Salary,Department_Id FROM EMPLOYEE_15 WHERE Department_Id NOT IN(10,30)
--6.	List out the employees whose name starts with 'S'
SELECT First_Name,Last_Name,Employee_Id FROM EMPLOYEE_15 WHERE Last_Name LIKE 'S%'
--7.	List out the employees whose name starts with 'S' and ends with 'H'
SELECT Employee_Id,First_Name,Last_Name FROM EMPLOYEE_15 WHERE Last_Name LIKE'S%H' 
--8.	List out the employees whose name length is 4 and start with 'S'.
SELECT Employee_Id,First_Name,Last_Name FROM EMPLOYEE_15 WHERE LEN(FIRST_NAME)=4 AND First_Name LIKE 'S%'
--9.		List out employees who are working in department 10 and draw salaries more than 3500.
SELECT Employee_Id,First_Name,Last_Name,Salary,Department_Id FROM EMPLOYEE_15 WHERE Department_Id=10 AND Salary>3500
--10.	List out the employees who are not receiving commission.
SELECT Employee_Id,First_Name,Last_Name,Commission FROM EMPLOYEE_15 WHERE Commission IS NULL


--1.	List out the Employee ID and Last Name in ascending order based on the Employee ID.
SELECT Employee_Id,Last_Name,First_Name FROM EMPLOYEE_15 ORDER BY Employee_Id
--2.	List out the Employee ID and Name in descending order based on salary.
SELECT Employee_Id,First_Name,Last_Name FROM EMPLOYEE_15 ORDER BY Salary DESC
--3.	List out the employee details according to their Last Name in ascending order.
SELECT * FROM EMPLOYEE_15 ORDER BY Last_Name ASC
--4.	List out the employee details according to their Last Name in ascending order and then Department ID in descending order.
SELECT* FROM EMPLOYEE_15 ORDER BY Last_Name ASC,Department_Id DESC

--1.	--How many employees are in different departments in the organization?
SELECT DEPARTMENT_ID,COUNT(*) AS EMPLOYEE_COUNT FROM EMPLOYEE_15 GROUP BY Department_Id
--2.	List out the department wise maximum salary, minimum salary and average salary of the employees.
SELECT Department_Id,MAX(Salary) AS MAXIMUM_SALARY,MIN(SALARY) AS MINIMUM_SALARY,AVG(SALARY) AS AVG_SALARY FROM EMPLOYEE_15 GROUP BY Department_Id
--3.	List out the job wise maximum salary, minimum salary and average salary of the employees.
SELECT Job_Id,MAX(Salary) AS MAXIMUM_SALARY,MIN(SALARY) AS MINIMUM_SALARY,AVG(SALARY) AS AVG_SALARY FROM EMPLOYEE_15 GROUP BY Job_Id

--4.	List out the number of employees who joined each month in ascending order.
SELECT DATEPART(MONTH,Hire_Date) AS JOIN_MONTH,COUNT(*) AS EMPLOYEE_COUNT FROM EMPLOYEE_15 GROUP BY DATEPART(MONTH,Hire_Date) ORDER BY JOIN_MONTH

--5.	List out the number of employees for each month and year in ascending order based on the year and month.
SELECT DATEPART(MONTH,Hire_Date) AS JOIN_MONTH,DATEPART(YEAR,Hire_Date) AS JOIN_YEAR,COUNT(*) AS EMPLOYEE_COUNT FROM EMPLOYEE_15 
GROUP BY DATEPART(MONTH,Hire_Date),DATEPART(YEAR,Hire_Date) ORDER BY JOIN_MONTH,JOIN_YEAR
--6.	List out the Department ID having at least four employees.
SELECT Department_Id FROM EMPLOYEE_15 GROUP BY Department_Id HAVING COUNT(*)<=4
--7.	How many employees joined in the month of January?
SELECT COUNT(*) AS JANUARY_JOINMONTH FROM EMPLOYEE_15 WHERE DATEPART(MONTH,HIRE_DATE)=1
--8.	How many employees joined in the month of January or September?
SELECT COUNT(*) AS JANUARY_SEPTEMBER_JOINMONTH_COUNT FROM EMPLOYEE_15 WHERE DATEPART(MONTH,HIRE_DATE)=1 OR DATEPART(MONTH,HIRE_DATE)=8
--9.	How many employees joined in 1985?
SELECT COUNT(*) JOIN_COUNT_1985 FROM EMPLOYEE_15 WHERE DATEPART(YEAR,HIRE_DATE)='1985'
--10.	How many employees joined each month in 1985?
SELECT DATEPART(MONTH,Hire_Date) AS JOIN_MONTH ,COUNT(*) AS JOIN_COUNT FROM EMPLOYEE_15 WHERE DATEPART(YEAR,HIRE_DATE)=1985 
GROUP BY DATEPART(MONTH,HIRE_DATE)
ORDER BY JOIN_COUNT
--11.	How many employees joined in March 1985?
SELECT COUNT(*) AS MARCH_MONTH_JOIN_COUNT FROM EMPLOYEE_15 WHERE DATEPART(MONTH,HIRE_DATE)=3 AND  DATEPART(YEAR,Hire_Date)=1985
--12.	Which is the Department ID having greater than or equal to 3 employees joining in April 1985?
SELECT Department_Id FROM EMPLOYEE_15 WHERE DATEPART(MONTH,HIRE_DATE)=4 AND DATEPART(YEAR,HIRE_DATE)=1985
GROUP BY Department_Id HAVING COUNT(*)>=3


----Joins:
--1.	List out employees with their department names.
SELECT E.Department_Id ,E.Employee_Id,E.FIRST_NAME,E.LAST_NAME,D.NAME AS DEPARTMENT_NAME FROM EMPLOYEE_15 E
JOIN DEPARTMENT_07 D ON E.Department_Id =D.DEPARTMENT_ID
--2.	Display employees with their designations.
SELECT E.Employee_Id,E.First_Name,E.Last_Name,J.DESIGNATION FROM EMPLOYEE_15 E 
JOIN  JOB_12 J ON E.Job_Id=J.JOB_ID
--3.	Display the employees with their department names and regional groups.
SELECT E.Employee_Id,E.First_Name,E.Last_Name,D.NAME AS DEPARTMENT_NAME,L.CITY 
FROM EMPLOYEE_15 E JOIN DEPARTMENT_07 D ON D.DEPARTMENT_ID=E.Department_Id
JOIN LOCATION_07 L ON D.LOCATION_ID=L.LOCATION_ID
--4.	How many employees are working in different departments? Display with department names.
SELECT D.NAME AS DEPARTMENT_NAME,COUNT(*) AS EMPOYEE_COUNT 
FROM EMPLOYEE_15 E JOIN DEPARTMENT_07 D ON D.DEPARTMENT_ID=E.Department_Id
GROUP BY D.NAME

--5.	How many employees are working in the sales department?
SELECT COUNT(*) AS EMPLOYEE_COUNT 
FROM EMPLOYEE_15 E JOIN DEPARTMENT_07 D ON D.DEPARTMENT_ID=E.Department_Id
WHERE D.NAME='SALES'
--6.	Which is the department having greater than or equal to 5 employees? Display the department names in ascending order.
 SELECT D.NAME AS DEPARTMENT_NAME 
 FROM DEPARTMENT_07 D JOIN EMPLOYEE_15 E  ON E.Department_Id=D.DEPARTMENT_ID
 GROUP BY D.NAME
 HAVING COUNT(*)>=5
 ORDER BY D.NAME
--7.	How many jobs are there in the organization? Display with designations.
SELECT COUNT(*) AS JOB_COUNT,DESIGNATION 
FROM JOB_12
GROUP BY DESIGNATION
--8.	How many employees are working in "New York"?
--provided question is wrong as there is link between location table and employee table
--9.	Display the employee details with salary grades.
SELECT First_Name,Last_Name,Middle_Name,Salary,
 CASE WHEN Salary>=2000 THEN 'A'
       WHEN Salary>=1000 THEN 'B'
	   WHEN  SALARY>= 800 THEN 'C'
	   ELSE 'D'
	   END AS SALARY_GRADE
	   FROM EMPLOYEE_15
	   ORDER BY SALARY_GRADE
--10.	List out the number of employees grade wise.
SELECT 
 CASE WHEN Salary>=2000 THEN 'A'
       WHEN Salary>=1000 THEN 'B'
	   WHEN  SALARY>= 800 THEN 'C'
	   ELSE 'D'
	   END AS SALARY_GRADE,
	   COUNT(*) AS EMPLOYEE_COUNT,Salary
	   FROM EMPLOYEE_15
	   GROUP BY SALARY

	   
--11.	Display the employee salary grades and the number of employees between 2000 to 5000 range of salary.
SELECT 
 CASE WHEN Salary>=2000 THEN 'A'
       WHEN Salary>=1000 THEN 'B'
	   WHEN  SALARY>= 800 THEN 'C'
	   ELSE 'D'
	   END AS SALARY_GRADE,
	   COUNT(*) AS EMPLOYEE_COUNT,Salary
	   FROM EMPLOYEE_15
	   WHERE SALARY BETWEEN 2000 AND 5000
	   GROUP BY SALARY
--12.	Display the employee details with their manager names.

SELECT E.Employee_Id,E.FIRST_NAME,E.Last_Name,E.Middle_Name,M.LAST_NAME AS MANAGER_LST_NAME,M.FIRST_NAME AS MANAGER_FIRST_NAME
FROM  EMPLOYEE_15 E JOIN EMPLOYEE_15 M  ON  E.Manager_Id=M.EMPLOYEE_ID
--13.	Display the employee details who earn more than their managers� salaries.
SELECT E.Employee_Id,E.First_Name,E.Last_Name,E.Salary AS EMP_SALARY,M.SALARY AS MAN_SALARY FROM EMPLOYEE_15 E
JOIN EMPLOYEE_15 M  ON  E.Manager_Id=M.Employee_Id
WHERE E.Salary>M.Salary

--14.	Show the number of employees working under every manager.
SELECT Manager_Id,COUNT(*) AS EMP_CONT FROM EMPLOYEE_15 GROUP BY Manager_Id
--15.	Display employee details with their manager names.

SELECT E.Employee_Id,E.FIRST_NAME,E.Last_Name,E.Middle_Name,M.LAST_NAME AS MANAGER_LST_NAME,M.FIRST_NAME AS MANAGER_FIRST_NAME
FROM  EMPLOYEE_15 E JOIN EMPLOYEE_15 M  ON  E.Manager_Id=M.EMPLOYEE_ID
--16.	Display all employees in sales or operation departments.

SELECT E.First_Name,E.Last_Name,E.Middle_Name,D. NAME AS DEPARTMENT_NAME 
FROM EMPLOYEE_15 E
JOIN DEPARTMENT_07 D ON E.Department_Id=D.DEPARTMENT_ID
WHERE D.NAME IN ('SALES','OPERATIONS')

-------SET OPERATORS-----
--1.	List out the distinct jobs in sales and accounting departments.
SELECT DISTINCT JOB_ID FROM EMPLOYEE_15 WHERE DEPARTMENT_ID IN(SELECT DEPARTMENT_ID FROM DEPARTMENT_07 WHERE NAME IN ('SALES','ACCOUNTING'));
--2.	List out all the jobs in sales and accounting departments.
SELECT  JOB_ID FROM EMPLOYEE_15 WHERE DEPARTMENT_ID IN(SELECT DEPARTMENT_ID FROM DEPARTMENT_07 WHERE NAME IN ('SALES','ACCOUNTING'));
--3.	List	out	the	common	jobs	in	research	and	accounting departments in ascending order.
SELECT Job_Id FROM EMPLOYEE_15 WHERE Department_Id =(SELECT Department_Id FROM DEPARTMENT_07 WHERE NAME ='RESERACH')
INTERSECT
SELECT Job_Id FROM EMPLOYEE_15 WHERE Department_Id=(SELECT Department_Id FROM DEPARTMENT_07 WHERE NAME ='ACCOUNTING')
ORDER BY Job_Id ASC

----Subqueries:
--1.	Display the employees list who got the maximum salary.
SELECT * FROM EMPLOYEE_15 WHERE Salary=(SELECT MAX(SALARY) FROM EMPLOYEE_15)
--2.	Display the employees who are working in the sales department.
SELECT * FROM EMPLOYEE_15 WHERE Department_Id=(SELECT Department_Id FROM DEPARTMENT_07 WHERE NAME='SALES')
--3.	Display the employees who are working as 'Clerk'.
SELECT * FROM EMPLOYEE_15 WHERE Job_Id=(SELECT Job_Id FROM JOB_12 WHERE DESIGNATION='CLERK')
--4.	Display the list of employees who are living in "New York".
SELECT * FROM EMPLOYEE_15 WHERE Department_Id=(SELECT LOCATION_ID FROM LOCATION_07 WHERE CITY='NEW YORK')
--5.	Find out the number of employees working in the sales department.
SELECT COUNT(*)  FROM EMPLOYEE_15 WHERE Department_Id=(SELECT Department_Id FROM DEPARTMENT_07 WHERE NAME='SALES')
--6.	Update the salaries of employees who are working as clerks on the basis of 10%.
 UPDATE EMPLOYEE_15
 SET Salary=Salary*1.1
 WHERE Job_Id=(SELECT Job_Id FROM JOB_12 WHERE DESIGNATION='CLERK')
 SELECT * FROM EMPLOYEE_15
--7.	Delete the employees who are working in the accounting department.
DELETE EMPLOYEE_15 WHERE Department_Id=(SELECT Department_Id FROM DEPARTMENT_07 WHERE NAME='ACCOUNTING')
--8.	Display the second highest salary drawing employee details.
SELECT * FROM( SELECT *,RANK() OVER (ORDER BY SALARY DESC) AS SALARY_RANK FROM EMPLOYEE_15)AS EMP WHERE SALARY_RANK='2'
--9.	Display the nth highest salary drawing employee details.
DECLARE @N INT;
SET @N=5;
SELECT * FROM(
SELECT *,RANK() OVER (ORDER BY SALARY DESC) AS SALARY_RANK FROM EMPLOYEE_15) AS EMP WHERE SALARY_RANK=@N;






--10.	List out the employees who earn more than every employee in department 30.
SELECT * FROM EMPLOYEE_15 WHERE Salary>(SELECT MAX(Salary) FROM EMPLOYEE_15 WHERE Department_Id=30)


--11.	List out the employees who earn more than the lowest salary in department 30.
 SELECT * FROM EMPLOYEE_15 WHERE Salary<(SELECT MAX(Salary) FROM EMPLOYEE_15 WHERE Department_Id=30)
--12.	Find out whose department has no employees.
SELECT D.NAME AS DEPARTMENT_NAME FROM DEPARTMENT_07 D LEFT JOIN EMPLOYEE_15 E ON E.DEPARTMENT_ID=D.DEPARTMENT_ID
WHERE Employee_Id IS NULL;
--13.	Find out which department has no employees.
SELECT D.NAME AS DEPARTMENT_NAME FROM DEPARTMENT_07 D LEFT JOIN EMPLOYEE_15 E ON D.DEPARTMENT_ID=E.Department_Id
GROUP BY D.NAME
HAVING COUNT(E.Employee_Id)=0
--14.	Find out the employees who earn greater than the average salary for their department.
SELECT * FROM EMPLOYEE_15 E WHERE E.Salary>(SELECT AVG(SALARY) FROM EMPLOYEE_15 WHERE Department_Id=E.Department_Id)
